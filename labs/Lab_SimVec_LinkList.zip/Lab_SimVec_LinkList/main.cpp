
//345678901234567890123456789012345678901234567890123456789012345678901234567890
/* 
 * File:   main.cpp
 * Author: Curtis Stephens
 * Created on February 21st, 2018 8:40 PM
 * Purpose:  Linked List Version 3 Objects - Procedures with ADT
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here
#include "LinkedList.h"
#include "SimpleVector.h"

//Global Constants Only, No Global Variables

//Function Prototypes Here

//000000001111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare an object and place in the linked list
    SimpleVector<int> obj(5);
    obj.getElementAt(3);
    //Test the object return
    
    //Deallocate memory


    //Exit
    return 0;
}
