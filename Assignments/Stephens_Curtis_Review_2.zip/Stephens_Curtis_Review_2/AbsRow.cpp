/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AbsRow.cpp
 * Author: curtisstephens
 * 
 * Created on March 6, 2018, 8:38 PM
 */

#include "AbsRow.h"

AbsRow::AbsRow() {
}

AbsRow::AbsRow(const AbsRow& orig) {
}

sRow::~AbsRow() {
}

